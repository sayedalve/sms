# BATTACK TOOLKIT

![battack by botolbaba](https://user-images.githubusercontent.com/67283431/85844424-891be080-b7c4-11ea-80bb-70e7915c1b84.jpg)

[![Github](https://img.shields.io/badge/Github-BOTOL--MEHEDI-green?style=flat-square&logo=github)](https://github.com/botolmehedi) 
[![Facebook](https://img.shields.io/badge/Facebook-TEAM--VVIRUS-blue?style=flat-square&logo=facebook)](https://www.facebook.com/groups/231747098048450) 
[![IYoutube](https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube)](https://www.youtube.com/mastertrick1)

***

# About BATTACK

```
BATTACK is a python based Toolkit. This is a set of tools to provide denial of service attacks. BATTACK is a SMS Bombing Toolkit. This tool works on both rooted Android device and Non-rooted Android device.
```

***

# Getting started

## Battack installation

> git clone https://github.com/botolmehedi/battack

> chmod +x *

> pip install -r requirements.txt

## Battack Using

> cd battack

> ls

> python2 battack.py

***
  
# EXAMPLES OF SMS BOMBING
    
> botol --tool SMS --target +8801711111111 --timeout 10 --threads 50

***
  
# VIDEO TUTORIAL & PASSWORD

> https://youtube.com/mastertrick1

***

# BATTACK Toolkit disclaimer

```
Usage of the BATTACK Toolkit for attacking targets without prior mutual consent is illegal.
It is the end user's responsibility to obey all applicable local, state, federal, and international laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.
```

***

# BATTACK Toolkit license

```
MIT License

Copyright (C) 2020, BotolMehedi. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
